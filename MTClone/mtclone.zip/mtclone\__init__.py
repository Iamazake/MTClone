"""mtclone — Gerenciador de APK open-source."""

__version__ = "0.1.0"
